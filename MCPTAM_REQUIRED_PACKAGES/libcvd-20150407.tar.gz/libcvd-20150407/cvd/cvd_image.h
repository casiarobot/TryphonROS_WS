
#ifdef __GNUC__
#warning This file is deprecated. Use cvd/image.h
#else //elif defined(which ever compilers support this)
#pragma warning "This file is deprecated. Use cvd/image.h"
#endif

#include <cvd/image.h>
