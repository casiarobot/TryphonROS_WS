#ifndef CVD_IMAGE_CONVERT_FWD_H
#define CVD_IMAGE_CONVERT_FWD_H

#include <cvd/image.h>
#include <map>
namespace CVD
{
	//Forward declarations for convert_image
  //template<class D, class C, class Conv> 	Image<D> convert_image(const BasicImage<C>& from, Conv& cv);
  //template<class D, class E, class F> std::pair<Image<D>, Image<E> >convert_image(const BasicImage<F>& from);
  //template<class D, class C> Image<D> convert_image(const BasicImage<C>& from);
}

#endif
