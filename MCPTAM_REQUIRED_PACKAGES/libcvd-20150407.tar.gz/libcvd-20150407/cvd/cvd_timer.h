
#ifdef __GNUC__
#warning This file is deprecated. Use cvd/timer.h
#else //elif defined(which ever compilers support this)
#pragma warning "This file is deprecated. Use cvd/timer.h"
#endif

#include <cvd/timer.h>
